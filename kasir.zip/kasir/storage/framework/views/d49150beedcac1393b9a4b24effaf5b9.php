<footer class="sticky-footer bg-white">
    <div class="container-fluid my-auto">
        <div class="copyright text-center my-auto">
            <span>
                &copy; <?php echo e(date('Y')); ?> Aplikasi Kasir
            </span>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\kasir\resources\views/layouts/footer.blade.php ENDPATH**/ ?>